CREATE TABLE locais (
    id_local INT PRIMARY KEY AUTO_INCREMENT,
    nome_local VARCHAR(100) NOT NULL,
    bloco VARCHAR(50)
);

CREATE TABLE chamados (
    id_chamado INT PRIMARY KEY AUTO_INCREMENT,
    descricao TEXT NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    prioridade INT NOT NULL,
    status VARCHAR(20) NOT NULL,
    id_local INT,
    FOREIGN KEY (id_local) REFERENCES locais(id_local)
);

CREATE TABLE atendimentos (
    id_atendimento INT PRIMARY KEY AUTO_INCREMENT,
    id_chamado INT NOT NULL,
    data_acao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    descricao_acao TEXT NOT NULL,
    FOREIGN KEY (id_chamado) REFERENCES chamados(id_chamado)
);

INSERT INTO locais (nome_local, bloco) VALUES 
('Sala 202', 'Bloco A'),
('Banheiro Masc', 'Bloco B'),
('Biblioteca', 'Principal');

INSERT INTO chamados (descricao, categoria, prioridade, status, id_local) VALUES 
('Lâmpada queimada', 'Iluminação', 4, 'Aberto', 1),
('Vazamento na descarga', 'Hidráulica', 8, 'Aberto', 2),
('Cadeira com pé quebrado', 'Mobiliário', 3, 'Resolvido', 3);

INSERT INTO atendimentos (id_chamado, descricao_acao) VALUES 
(1, 'Verificado tipo de reator necessário para a troca.'),
(2, 'Fechado o registro geral para conter o vazamento temporariamente.'),
(3, 'Cadeira recolhida e enviada para a marcenaria da escola.');
