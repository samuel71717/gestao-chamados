import React from 'react';
import type { Chamado } from '../types';


interface ChamadoItemProps {
  chamado: Chamado;
  onResolver: (id: string) => void;
}

export const ChamadoItem: React.FC<ChamadoItemProps> = ({ chamado, onResolver }) => {
  const isUrgente = chamado.prioridade >= 7 && chamado.status === 'Aberto';

  return (
    <div style={{
      border: isUrgente ? '2px solid red' : '1px solid #ddd',
      backgroundColor: isUrgente ? '#ffe6e6' : '#fff',
      padding: '12px',
      marginBottom: '10px',
      borderRadius: '6px'
    }}>
      <h4>{chamado.descricao} {isUrgente && <span style={{ color: 'red', fontWeight: 'bold' }}>⚠️ URGENTE</span>}</h4>
      <p><strong>Local:</strong> {chamado.local} | <strong>Categoria:</strong> {chamado.categoria}</p>
      <p><strong>Prioridade:</strong> {chamado.prioridade} | <strong>Status:</strong> {chamado.status}</p>
      {chamado.status === 'Aberto' && (
        <button onClick={() => onResolver(chamado.id)} style={{ padding: '5px 10px', backgroundColor: '#28a745', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
          Registrar Solução
        </button>
      )}
    </div>
  );
};
