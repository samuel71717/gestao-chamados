import React, { useState } from 'react';
import type { Chamado } from '../types';

interface ChamadoFormProps {
  onAddChamado: (chamado: Omit<Chamado, 'id' | 'status'>) => void;
}

export const ChamadoForm: React.FC<ChamadoFormProps> = ({ onAddChamado }) => {
  const [descricao, setDescricao] = useState('');
  const [categoria, setCategoria] = useState<'Iluminação' | 'Hidráulica' | 'Mobiliário' | 'Climatização'>('Iluminação');
  const [local, setLocal] = useState('');
  const [prioridade, setPrioridade] = useState(5);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!descricao || !local) return alert('Preencha todos os campos!');
    onAddChamado({ descricao, categoria, local, prioridade });
    setDescricao('');
    setLocal('');
    setPrioridade(5);
  };

  return (
    <form onSubmit={handleSubmit} style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '8px', marginBottom: '20px' }}>
      <h3>Novo Chamado de Manutenção</h3>
      <div style={{ marginBottom: '10px' }}>
        <label>Descrição: </label>
        <input type="text" value={descricao} onChange={e => setDescricao(e.target.value)} style={{ width: '100%', padding: '5px' }} />
      </div>
      <div style={{ marginBottom: '10px' }}>
        <label>Local: </label>
        <input type="text" value={local} onChange={e => setLocal(e.target.value)} style={{ width: '100%', padding: '5px' }} />
      </div>
      <div style={{ marginBottom: '10px' }}>
        <label>Categoria: </label>
        <select value={categoria} onChange={e => setCategoria(e.target.value as any)} style={{ width: '100%', padding: '5px' }}>
          <option value="Iluminação">Iluminação</option>
          <option value="Hidráulica">Hidráulica</option>
          <option value="Mobiliário">Mobiliário</option>
          <option value="Climatização">Climatização</option>
        </select>
      </div>
      <div style={{ marginBottom: '10px' }}>
        <label>Prioridade (1 a 10): </label>
        <input type="number" min="1" max="10" value={prioridade} onChange={e => setPrioridade(Number(e.target.value))} style={{ width: '100%', padding: '5px' }} />
      </div>
      <button type="submit" style={{ padding: '8px 15px', backgroundColor: '#007bff', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Registrar Chamado</button>
    </form>
  );
};
