export interface Chamado {
  id: string;
  descricao: string;
  categoria: 'Iluminação' | 'Hidráulica' | 'Mobiliário' | 'Climatização';
  local: string;
  prioridade: number;
  status: 'Aberto' | 'Resolvido';
}

export interface HistoricoLog {
  id: string;
  timestamp: string;
  acao: string;
}
