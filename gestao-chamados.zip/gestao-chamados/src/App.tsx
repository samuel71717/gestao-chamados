import { useState } from 'react';
import type { Chamado, HistoricoLog } from './types';
import { ChamadoForm } from './components/ChamadoForm';
import { ChamadoItem } from './components/ChamadoItem';

const dadosIniciais: Chamado[] = [
  { id: '1', descricao: 'Lâmpada queimada na sala 202', categoria: 'Iluminação', local: 'Bloco A', prioridade: 4, status: 'Aberto' },
  { id: '2', descricao: 'Vazamento na descarga do banheiro', categoria: 'Hidráulica', local: 'Bloco B', prioridade: 8, status: 'Aberto' },
  { id: '3', descricao: 'Cadeira com pé quebrado', categoria: 'Mobiliário', local: 'Biblioteca', prioridade: 3, status: 'Resolvido' },
  { id: '4', descricao: 'Ar condicionado fazendo barulho alto', categoria: 'Climatização', local: 'Laboratório 3', prioridade: 6, status: 'Aberto' },
  { id: '5', descricao: 'Torneira não fecha totalmente', categoria: 'Hidráulica', local: 'Pátio Central', prioridade: 7, status: 'Aberto' },
];

export default function App() {
  const [chamados, setChamados] = useState<Chamado[]>(dadosIniciais);
  const [historico, setHistorico] = useState<HistoricoLog[]>([
    { id: 'h1', timestamp: new Date().toLocaleTimeString(), acao: 'Sistema inicializado com dados base.' }
  ]);
  const [filtro, setFiltro] = useState<string>('Todos');

  const chamadosAbertosCount = chamados.filter(c => c.status === 'Aberto').length;
  const exibirAlertaCritico = chamadosAbertosCount >= 8;

  const handleAddChamado = (novo: Omit<Chamado, 'id' | 'status'>) => {
    const chamadoCompleto: Chamado = {
      ...novo,
      id: Math.random().toString(),
      status: 'Aberto'
    };
    setChamados(prev => [chamadoCompleto, ...prev]);
    setHistorico(prev => [{
      id: Math.random().toString(),
      timestamp: new Date().toLocaleTimeString(),
      acao: `Chamado criado: "${novo.descricao}" em ${novo.local} (Prioridade: ${novo.prioridade})`
    }, ...prev]);
  };

  const handleResolverChamado = (id: string) => {
    setChamados(prev => prev.map(c => c.id === id ? { ...c, status: 'Resolvido' } : c));
    const chamado = chamados.find(c => c.id === id);
    setHistorico(prev => [{
      id: Math.random().toString(),
      timestamp: new Date().toLocaleTimeString(),
      acao: `Solução registrada para o chamado: "${chamado?.descricao}"`
    }, ...prev]);
  };

  const chamadosFiltrados = chamados.filter(c => filtro === 'Todos' || c.categoria === filtro);

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px', fontFamily: 'sans-serif', color: '#333' }}>
      <header style={{ backgroundColor: '#f8f9fa', padding: '15px', borderRadius: '8px', marginBottom: '20px', textAlign: 'center', borderBottom: '4px solid #007bff' }}>
        <h2>Gestão de Chamados de Manutenção Predial</h2>
        <small style={{ color: '#555', fontWeight: 'bold' }}>Código da Prova: PP-1KAUDEK-1E0EEI6</small>
      </header>

      {exibirAlertaCritico && (
        <div style={{ backgroundColor: '#dc3545', color: '#fff', padding: '15px', borderRadius: '6px', marginBottom: '20px', fontWeight: 'bold', textAlign: 'center' }}>
          ⚠️ ALERTA CRÍTICO DE CAPACIDADE: Existem {chamadosAbertosCount} chamados abertos no momento! (Limite de 8 atingido).
        </div>
      )}

      <ChamadoForm onAddChamado={handleAddChamado} />

      <div style={{ marginBottom: '15px' }}>
        <label><strong>Filtrar por Categoria: </strong></label>
        <select value={filtro} onChange={e => setFiltro(e.target.value)} style={{ padding: '5px', marginLeft: '10px' }}>
          <option value="Todos">Todos</option>
          <option value="Iluminação">Iluminação</option>
          <option value="Hidráulica">Hidráulica</option>
          <option value="Mobiliário">Mobiliário</option>
          <option value="Climatização">Climatização</option>
        </select>
      </div>

      <h3>Lista de Chamados</h3>
      {chamadosFiltrados.length === 0 ? (
        <p style={{ color: '#777', fontStyle: 'italic', padding: '10px', backgroundColor: '#eee', borderRadius: '4px' }}>
          Nenhum chamado encontrado para este filtro.
        </p>
      ) : (
        chamadosFiltrados.map(c => (
          <ChamadoItem key={c.id} chamado={c} onResolver={handleResolverChamado} />
        ))
      )}

      <div style={{ marginTop: '30px', padding: '15px', backgroundColor: '#f1f3f5', borderRadius: '8px' }}>
        <h3>📜 Histórico Recente de Operações</h3>
        <ul style={{ maxHeight: '150px', overflowY: 'auto', paddingLeft: '20px' }}>
          {historico.map(log => (
            <li key={log.id} style={{ fontSize: '14px', marginBottom: '5px', color: '#333' }}>
              <span style={{ color: '#666' }}>[{log.timestamp}]</span> {log.acao}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
